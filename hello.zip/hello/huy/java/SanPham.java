package com.dmt.duchuy.myapplication;

public class SanPham {
    private String ma,ten;
    private int soLuong,maDanhMuc;

    public SanPham(String ma, String ten, int soLuong, int maDanhMuc) {
        this.ma = ma;
        this.ten = ten;
        this.soLuong = soLuong;
        this.maDanhMuc = maDanhMuc;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public int getMaDanhMuc() {
        return maDanhMuc;
    }

    public void setMaDanhMuc(int maDanhMuc) {
        this.maDanhMuc = maDanhMuc;
    }
    public SanPham()
    {

    }
}
