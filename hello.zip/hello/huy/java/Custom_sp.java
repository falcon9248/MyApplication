package com.dmt.duchuy.myapplication;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Custom_sp extends ArrayAdapter<SanPham> {
    private Context context;
    private int resource;
    private ArrayList<SanPham> ds;
    public Custom_sp(@NonNull Context context, int resource, @NonNull ArrayList<SanPham> objects) {
        super(context, resource, objects);
        this.context=context;
        this.resource=resource;
        this.ds=objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        convertView= LayoutInflater.from(context).inflate(R.layout.sanpham,parent,false);

        TextView ma=(TextView) convertView.findViewById(R.id.MA);
        TextView ten=(TextView) convertView.findViewById(R.id.TEN);
        TextView soluong=(TextView) convertView.findViewById(R.id.SOLUONG);
        TextView madanhmuc=(TextView) convertView.findViewById(R.id.MADANHMUC);

        ma.setText(ds.get(position).getMa());
        ten.setText(ds.get(position).getTen());
        soluong.setText(ds.get(position).getSoLuong()+"");
        madanhmuc.setText(ds.get(position).getMaDanhMuc()+"");

        return convertView;

    }
}
