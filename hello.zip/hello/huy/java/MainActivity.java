package com.dmt.duchuy.myapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DbManager db;
    EditText edt_tim;
    Button btn_Tim,danhmuc;

    ListView ds;
    Custom_HoaDon adt;
    ArrayList<HoaDon> hd;

    Custom_ChiTiet adt_ChiTiet;
    ArrayList<ChiTiet> ct;
    ListView ds1;
    Button ds_SanPham,QuanLy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db=new DbManager(this);
        edt_tim=(EditText) findViewById(R.id.Edt_Tim);
        btn_Tim=(Button) findViewById(R.id.Btn_Tim);
        QuanLy=(Button) findViewById(R.id.QuanLySanPham);
        ds_SanPham=(Button) findViewById(R.id.Ds_SanPham);
        danhmuc=(Button) findViewById(R.id.QuanLyDanhMuc);
        ds=(ListView) findViewById(R.id.DanhSach);

        danhmuc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,QuanLyDanhMuc.class);
                startActivity(intent);
            }
        });
        //hd=db.TimKiemHoaDon("HD161");
        hd=new ArrayList<>();
        adt=new Custom_HoaDon(this,R.layout.item_hoadon,hd);
        ds.setAdapter(adt);

        ds1=findViewById(R.id.ds_ChiTietHD);
        ct=new ArrayList<>();
        adt_ChiTiet=new Custom_ChiTiet(this,R.layout.item_chitiet,ct);
        ds1.setAdapter(adt_ChiTiet);

        btn_Tim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ma=edt_tim.getText().toString().trim();
                ArrayList<HoaDon> xx=db.TimKiemHoaDon(ma);
                hd.clear();
                hd.addAll(xx);
                adt.notifyDataSetChanged();

            }
        });
        ds.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                HoaDon x=hd.get(position);
                ArrayList<ChiTiet> yy=db.TimKiemChiTiet(x.getMa());
                ct.clear();
                ct.addAll(yy);
                adt_ChiTiet.notifyDataSetChanged();
                Toast.makeText(MainActivity.this, yy.size()+"", Toast.LENGTH_SHORT).show();

            }
        });


        ds_SanPham.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,DanhSachSanPham.class);
                startActivity(intent);
            }
        });
        QuanLy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,QuanLy.class);
                startActivity(intent);
            }
        });

    }
}
