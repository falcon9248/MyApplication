package com.dmt.duchuy.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class QuanLy extends AppCompatActivity {
    EditText ma,ten,soLuong;
    Button sua,them,xoa;
    Spinner spinner;
    ListView list;
    Custom_sp adt;
    DbManager db;
    ArrayList<DanhMuc> arr_DanhMuc;
    ArrayList<SanPham> arr_SanPham;
    Custom_sp adt_SanPham;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quan_ly);
        ma=(EditText) findViewById(R.id.ma);
        ten=(EditText) findViewById(R.id.ten);
        soLuong=(EditText) findViewById(R.id.soluong);
        spinner=(Spinner) findViewById(R.id.spiner);
        list=(ListView) findViewById(R.id.danhsach);
        sua=(Button) findViewById(R.id.sua);
        them=(Button) findViewById(R.id.them);
        xoa=(Button) findViewById(R.id.xoa);
        db=new DbManager(this);

        //set spiner
        ArrayList<String> ds_MaDanhMuc=new ArrayList<>();
        arr_DanhMuc=db.getAllDanhMuc();
        Toast.makeText(this, arr_DanhMuc.size()+"", Toast.LENGTH_SHORT).show();
        for(int i=0;i<arr_DanhMuc.size();i++)
        {
            ds_MaDanhMuc.add(arr_DanhMuc.get(i).getMa()+"");
        }
        ArrayAdapter<String> adt_DanhMuc=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ds_MaDanhMuc);
        spinner.setAdapter(adt_DanhMuc);
        //
        arr_SanPham=db.GetAllSanPham();
        adt_SanPham=new Custom_sp(this,R.layout.sanpham,arr_SanPham);
        list.setAdapter(adt_SanPham);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ma.setText(arr_SanPham.get(position).getMa()+"");
                ten.setText(arr_SanPham.get(position).getTen()+"");
                soLuong.setText(arr_SanPham.get(position).getSoLuong()+"");

            }
        });

        sua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean check=true;
                String m=ma.getText()+"";
                if(m.length()==0)
                {
                    check=false;
                    Toast.makeText(QuanLy.this, "Chua nhap du liei", Toast.LENGTH_SHORT).show();
                }
                String t=ten.getText()+"";
                int sl=0;
                try
                {
                    sl=Integer.parseInt(soLuong.getText()+"");
                }catch (Exception e)
                {
                    Toast.makeText(QuanLy.this, "Ko la so", Toast.LENGTH_SHORT).show();
                    check=false;
                }
                int maDm=Integer.parseInt(spinner.getSelectedItem().toString());
                if(check==false)
                {
                    Toast.makeText(QuanLy.this, "Du lieu nhap chua dung", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    SanPham sp=new SanPham(m,t,sl,maDm);
                    db.Update(sp);

                    arr_SanPham.clear();
                    arr_SanPham.addAll(db.GetAllSanPham());
                    adt_SanPham.notifyDataSetChanged();
                }

            }
        });

        them.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String m=ma.getText()+"";
                String t=ten.getText()+"";
                boolean check=true;
                for(int i=0;i<arr_SanPham.size();i++)
                {
                    if(arr_SanPham.get(i).getMa().equals(m))
                    {
                        Toast.makeText(QuanLy.this, "Ma trung", Toast.LENGTH_SHORT).show();
                        check=false;
                    }
                }
                if(soLuong.getText().length()==0)
                {
                    check=false;
                }


                if(check==true)
                {
                    int sl=Integer.parseInt(soLuong.getText()+"");
                    int maDm=Integer.parseInt(spinner.getSelectedItem().toString());
                    SanPham sp=new SanPham(m,t,sl,maDm);
                    db.AddSanPham(sp);

                    arr_SanPham.clear();
                    arr_SanPham.addAll(db.GetAllSanPham());
                    adt_SanPham.notifyDataSetChanged();
                }
                else
                {
                    Toast.makeText(QuanLy.this, "Du lieu khong dung", Toast.LENGTH_SHORT).show();
                }
            }
        });

        xoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String m=ma.getText().toString();
                int kq=db.DeleteSanPham(m);
                if(kq>0)
                {
                    Toast.makeText(QuanLy.this, "Xoa thanh cong", Toast.LENGTH_SHORT).show();
                    arr_SanPham.clear();
                    arr_SanPham.addAll(db.GetAllSanPham());
                    adt_SanPham.notifyDataSetChanged();
                }
                else
                {
                    Toast.makeText(QuanLy.this, "Xoa that bai", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
