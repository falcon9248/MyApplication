package com.dmt.duchuy.myapplication;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Custom_ChiTiet extends ArrayAdapter<ChiTiet> {
    private Context context;
    private int resource;
    private ArrayList<ChiTiet> ds;
    public Custom_ChiTiet(@NonNull Context context, int resource, @NonNull ArrayList<ChiTiet> objects) {
        super(context, resource, objects);
        this.context=context;
        this.resource=resource;
        this.ds=objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        convertView= LayoutInflater.from(context).inflate(R.layout.item_chitiet,parent,false);
        TextView ma=(TextView) convertView.findViewById(R.id.maHD);
        TextView maSp=(TextView) convertView.findViewById(R.id.maSP);

        ma.setText(ds.get(position).getMaHoaDon());
        maSp.setText(ds.get(position).getMaSanPham());

        return convertView;
    }
}
