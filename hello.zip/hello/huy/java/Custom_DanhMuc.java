package com.dmt.duchuy.myapplication;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Custom_DanhMuc extends ArrayAdapter<DanhMuc> {
    private Context context;
    private int resource;
    private ArrayList<DanhMuc> ds;
    public Custom_DanhMuc(@NonNull Context context, int resource, @NonNull ArrayList<DanhMuc> objects) {
        super(context, resource, objects);
        this.context=context;
        this.resource=resource;
        this.ds=objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        convertView= LayoutInflater.from(context).inflate(R.layout.item_danhmuc,parent,false);
        TextView ma=(TextView) convertView.findViewById(R.id.MDM);
        TextView ten=(TextView) convertView.findViewById(R.id.TDM);

        ma.setText(ds.get(position).getMa()+"");
        ten.setText(ds.get(position).getTen()+"");
        return convertView;
    }
}
