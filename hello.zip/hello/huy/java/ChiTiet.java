package com.dmt.duchuy.myapplication;

public class ChiTiet {
    private String maHoaDon,maSanPham;

    public String getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(String maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public String getMaSanPham() {
        return maSanPham;
    }

    public void setMaSanPham(String maSanPham) {
        this.maSanPham = maSanPham;
    }

    public ChiTiet(String maHoaDon, String maSanPham) {
        this.maHoaDon = maHoaDon;
        this.maSanPham = maSanPham;
    }
    public ChiTiet()
    {

    }
}
