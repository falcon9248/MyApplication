package com.dmt.duchuy.myapplication;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Custom_SanPham extends ArrayAdapter<SanPham> {
    private Context context;
    private int resource;
    private ArrayList<SanPham> ds;
    public Custom_SanPham(@NonNull Context context, int resource, @NonNull ArrayList<SanPham> objects) {
        super(context, resource, objects);
        this.context=context;
        this.resource=resource;
        this.ds=objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        convertView= LayoutInflater.from(context).inflate(R.layout.item_sanpham,parent,false);
        TextView ma=(TextView) convertView.findViewById(R.id.ma_SP);
        TextView ten=(TextView) convertView.findViewById(R.id.ten_SP);
        TextView soLuong=(TextView) convertView.findViewById(R.id.soLuong_SP);
        TextView maDanhMuc=(TextView) convertView.findViewById(R.id.ma_DM);

        ma.setText(ds.get(position).getMa());
        ten.setText(ds.get(position).getTen());
        soLuong.setText(ds.get(position).getSoLuong()+"");
        maDanhMuc.setText(ds.get(position).getMaDanhMuc()+"");

        return convertView;

    }
}
