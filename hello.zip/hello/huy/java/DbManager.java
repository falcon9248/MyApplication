package com.dmt.duchuy.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DbManager extends SQLiteOpenHelper {
    public static final String Database="DoCaoTri_1501211";



    public DbManager(Context context){
        super(context,Database,null,1);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        //tao bang
        String DanhMuc="Create table If not exists DanhMuc(maDanhMuc Integer primary key Autoincrement,tenDanhMuc text)";
        String SanPham="Create table If not exists SanPham(maSanPham text primary key,tenSanPham text,soLuong Integer,maDanhMuc Integer,foreign key(maDanhMuc) references DanhMuc(maDanhMuc) on delete cascade)";
        String HoaDon="Create table If not exists HoaDon(maHoaDon text primary key,trangThai text,ngayLap String)";
        String chiTiet="Create table If not exists ChiTiet(maHoaDon text,maSanPham text,primary key(maHoaDon,maSanPham))";
        //Them DuLieu

        String dm1="Insert into DanhMuc Values(1,'DienThoai')";
        String dm2="Insert into DanhMuc Values(2,'Xe')";

        String sp1="Insert into SanPham Values('SP123','Iphone',3,1)";
        String sp2="Insert into SanPham Values('SP124','XeDap',6,2)";

        String hd1="Insert into HoaDon Values('HD161','XacNhan','12/12/2018')";
        String hd2="Insert into HoaDon Values('HD162','XacNhan','24/12/2018')";

        String ct1="Insert into ChiTiet Values('HD161','SP123')";
        String ct2="Insert into ChiTiet Values('HD161','SP124')";

        db.execSQL(DanhMuc);
        db.execSQL(SanPham);
        db.execSQL(HoaDon);
        db.execSQL(chiTiet);
        db.execSQL(dm1);
        db.execSQL(dm2);
        db.execSQL(sp1);
        db.execSQL(sp2);
        db.execSQL(hd1);
        db.execSQL(hd2);
        db.execSQL(ct1);
        db.execSQL(ct2);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    //cau 1:tim kiem ma hoa don
    public ArrayList<HoaDon> TimKiemHoaDon(String ma)
    {
        ArrayList<HoaDon> ds=new ArrayList<>();
        SQLiteDatabase db=getWritableDatabase();
        Cursor cursor=db.rawQuery("Select * from HoaDon where maHoaDon=?",new String[]{ma});
        if(cursor.moveToFirst())
        {
            do {
                HoaDon hd=new HoaDon();
                hd.setMa(cursor.getString(0));
                hd.setTrangthai(cursor.getString(1));
                hd.setNgayLap(cursor.getString(2));
                ds.add(hd);
            }while (cursor.moveToNext());
        }
        return ds;
    }
    //cau 2:xem chi tiet danh sach hoa don
    public ArrayList<ChiTiet> TimKiemChiTiet(String maHD)
    {
        ArrayList<ChiTiet> ds=new ArrayList<>();
        SQLiteDatabase db=getWritableDatabase();
        Cursor cursor=db.rawQuery("Select * from ChiTiet Where maHoaDon=?",new String[]{maHD});
        if(cursor.moveToFirst())
        {
            do {
                ChiTiet ct=new ChiTiet();
                ct.setMaHoaDon(cursor.getString(0));
                ct.setMaSanPham(cursor.getString(1));
                ds.add(ct);
            }while (cursor.moveToNext());
        }
        return ds;
    }
    //cau 3:
    public ArrayList<SanPham> GetAllSanPham()
    {
        SQLiteDatabase db=getWritableDatabase();
        String sql="select * from SanPham";
        ArrayList<SanPham> ds=new ArrayList<>();
        Cursor cursor=db.rawQuery(sql,null);
        if(cursor.moveToFirst())
        {
            do {
                SanPham sp=new SanPham();
                sp.setMa(cursor.getString(0));
                sp.setTen(cursor.getString(1));
                sp.setSoLuong(cursor.getInt(2));
                sp.setMaDanhMuc(cursor.getInt(3));
                ds.add(sp);
            }while (cursor.moveToNext());
        }
        return ds;
    }
    //cau 4:Them hoa Don
    public void ThemHoaDon(HoaDon a)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("maHoaDon",a.getMa());
        values.put("trangThai",a.getTrangthai());
        values.put("ngayLap",a.getNgayLap());

        db.insert("HoaDon",null,values);
        db.close();
    }
    //cau 5:Them chi tiet hoa don
    public void ThemChiTiet(ChiTiet ct)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("maHoaDon",ct.getMaHoaDon());
        values.put("maSanPham",ct.getMaSanPham());

        db.insert("ChiTiet",null,values);
    }
    //cau 6:
    public ArrayList<DanhMuc> getAllDanhMuc()
    {
        SQLiteDatabase db=getWritableDatabase();
        String sql="Select * from DanhMuc";
        ArrayList<DanhMuc> ds=new ArrayList<>();
        Cursor cursor=db.rawQuery(sql,null);
        if(cursor.moveToFirst())
        {
            do {
                DanhMuc dm=new DanhMuc();
                dm.setMa(cursor.getInt(0));
                dm.setTen(cursor.getString(1));
                ds.add(dm);
            }while (cursor.moveToNext());
        }
        return ds;
    }
    //cau 7:Sua san pham
    public int Update(SanPham x)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("maSanPham",x.getMa()+"");
        values.put("tenSanPham",x.getTen()+"");
        values.put("soLuong",x.getSoLuong());
        values.put("maDanhMuc",x.getMaDanhMuc());
        return db.update("SanPham",values,"maSanPham=?",new String[]{x.getMa()});

    }
    //cau 8:The
    public void AddSanPham(SanPham sp)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("maSanPham",sp.getMa()+"");
        values.put("tenSanPham",sp.getTen()+"");
        values.put("soLuong",sp.getSoLuong());
        values.put("maDanhMuc",sp.getMaDanhMuc());

        db.insert("SanPham",null,values);
        db.close();
    }
    //cau 9:Xoa
    public int DeleteSanPham(String ma)
    {
        SQLiteDatabase db=getWritableDatabase();
        return  db.delete("SanPham","maSanPham=?",new String[]{ma});

    }
    //cau 10:update danhmuc
    public int updateDanhMuc(DanhMuc x)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("maDanhMuc",x.getMa());
        values.put("tenDanhMuc",x.getTen());
        return db.update("DanhMuc",values,"maDanhMuc=?",new String[]{String.valueOf(x.getMa())});

    }
    public void AddDanhMuc(DanhMuc dm)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues values=new ContentValues();

        values.put("tenDanhMuc",dm.getTen());
        db.insert("DanhMuc",null,values);
    }
    public int XoaDanhMuc(String ma)
    {
        SQLiteDatabase db=getWritableDatabase();
        return  db.delete("DanhMuc","maDanhMuc=?",new String[]{ma});
    }


}
