package com.dmt.duchuy.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class QuanLyDanhMuc extends AppCompatActivity {
    EditText ma,ten;
    Button them,xoa,s,t;
    DbManager db;
    Custom_DanhMuc adt;
    ArrayList<DanhMuc> ds;
    ListView lst;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quan_ly_danh_muc);

        ma=(EditText) findViewById(R.id.madanhmuc);
        ten=(EditText) findViewById(R.id.tendanhmuc);
        lst=(ListView) findViewById(R.id.dsDanhMuc);
        s=(Button) findViewById(R.id.sua);
        t=(Button) findViewById(R.id.them);
        xoa=(Button) findViewById(R.id.xoa);

        db=new DbManager(this);
        ds=db.getAllDanhMuc();
        adt=new Custom_DanhMuc(this,R.layout.item_danhmuc,ds);
        lst.setAdapter(adt);

        lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ma.setText(ds.get(position).getMa()+"");
                ten.setText(ds.get(position).getTen()+"");

            }
        });
        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DanhMuc dm=new DanhMuc();
                int m=Integer.parseInt(ma.getText()+"");
                String t=ten.getText()+"";
                dm.setMa(m);
                dm.setTen(t);
                db.updateDanhMuc(dm);
                Toast.makeText(QuanLyDanhMuc.this, "Cap nhat thanh cong", Toast.LENGTH_SHORT).show();

                ds.clear();
                ds.addAll(db.getAllDanhMuc());
                adt.notifyDataSetChanged();
            }
        });

        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String t=ten.getText()+"";
                DanhMuc dm=new DanhMuc();
                dm.setTen(t);
                db.AddDanhMuc(dm);
                Toast.makeText(QuanLyDanhMuc.this, "Them thanh cong", Toast.LENGTH_SHORT).show();

                ds.clear();
                ds.addAll(db.getAllDanhMuc());
                adt.notifyDataSetChanged();
            }
        });

        xoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x=ma.getText()+"";
                int kq=db.XoaDanhMuc(x);
                if(kq>0)
                {
                    Toast.makeText(QuanLyDanhMuc.this, "Xoa thanh cong", Toast.LENGTH_SHORT).show();
                    ds.clear();
                    ds.addAll(db.getAllDanhMuc());
                    adt.notifyDataSetChanged();
                }
                else
                {
                    Toast.makeText(QuanLyDanhMuc.this, "Xoa that bai", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

}
