package com.dmt.duchuy.myapplication;

import java.net.PortUnreachableException;

public class HoaDon {
    private String ma,trangthai,ngayLap;

    public HoaDon(String ma, String trangthai, String ngayLap) {
        this.ma = ma;
        this.trangthai = trangthai;
        this.ngayLap = ngayLap;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(String trangthai) {
        this.trangthai = trangthai;
    }

    public String getNgayLap() {
        return ngayLap;
    }

    public void setNgayLap(String ngayLap) {
        this.ngayLap = ngayLap;
    }
    public HoaDon()
    {

    }
}
