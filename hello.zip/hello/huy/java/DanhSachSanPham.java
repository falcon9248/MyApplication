package com.dmt.duchuy.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class DanhSachSanPham extends AppCompatActivity {
    ListView ds;
    Button thanhToan;
    Custom_SanPham adt;
    DbManager db;
    ArrayList<SanPham> dsSanPham;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danh_sach_san_pham);

        db=new DbManager(this);
        dsSanPham=db.GetAllSanPham();
        thanhToan=(Button) findViewById(R.id.ThanhToan);
        ds=(ListView) findViewById(R.id.DanhSachSanPham);
        adt=new Custom_SanPham(this,R.layout.item_sanpham,dsSanPham);
        ds.setAdapter(adt);

        thanhToan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* HoaDon x=new HoaDon("HD132","XacNhan","24/12/2018");
                db.ThemHoaDon(x);*/
                for(int i=0;i<ds.getChildCount();i++)
                {
                    View x=ds.getChildAt(i);
                    CheckBox chk=(CheckBox) x.findViewById(R.id.chk_Chon);
                    if(chk.isChecked())
                    {
                        SanPham t=dsSanPham.get(i);
                        ChiTiet ct=new ChiTiet();
                        ct.setMaSanPham(t.getMa());
                        ct.setMaHoaDon("HD132");
                        db.ThemChiTiet(ct);
                    }
                }
                Toast.makeText(DanhSachSanPham.this, "ThemThanhCong", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
