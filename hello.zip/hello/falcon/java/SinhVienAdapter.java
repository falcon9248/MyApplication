package com.example.falcon.cuoikyandroid;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SinhVienAdapter extends ArrayAdapter<SinhVien> {

    private Context context;
    private int resource;
    private ArrayList<SinhVien> arrSV;

    public SinhVienAdapter(@NonNull Context context, int resource, @NonNull ArrayList<SinhVien> arrSV) {
        super(context, resource, arrSV);
        this.context=context;
        this.resource=resource;
        this.arrSV = arrSV;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        ViewHolder viewHolder;
        if(convertView==null){
            convertView = LayoutInflater.from(context).inflate(R.layout.custom_list_view,parent,false);
            viewHolder = new ViewHolder();
            viewHolder.tvMSSV = convertView.findViewById(R.id.tvMSSV);
            viewHolder.tvTenSV = convertView.findViewById(R.id.tvTenSV);
            viewHolder.tvLop = convertView.findViewById(R.id.tvLop);

            convertView.setTag(viewHolder);

        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        SinhVien sv = arrSV.get(position);
        viewHolder.tvMSSV.setText(String.valueOf(sv.getMssv()));
        viewHolder.tvTenSV.setText(sv.getTenSV());
        viewHolder.tvLop.setText(sv.getLop());
        

        return convertView;
    }

    class ViewHolder{
        TextView tvMSSV,tvTenSV,tvLop;
    }

}
