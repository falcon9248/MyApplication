package com.example.falcon.cuoikyandroid;

import java.io.Serializable;
import java.util.Date;

public class HoaDon implements Serializable {
    private String maHD;
    private String maSV;
    private String ngayLap;

    @Override
    public String toString() {
        return "HoaDon{" +
                "maHD='" + maHD + '\'' +
                ", maSV='" + maSV + '\'' +
                ", ngayLap='" + ngayLap + '\'' +
                '}';
    }

    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }

    public String getMaSV() {
        return maSV;
    }

    public void setMaSV(String maSV) {
        this.maSV = maSV;
    }

    public String getNgayLap() {
        return ngayLap;
    }

    public void setNgayLap(String ngayLap) {
        this.ngayLap = ngayLap;
    }

    public HoaDon(String maHD, String maSV, String ngayLap) {

        this.maHD = maHD;
        this.maSV = maSV;
        this.ngayLap = ngayLap;
    }
}
