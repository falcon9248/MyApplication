package com.example.falcon.cuoikyandroid;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;

public class SqliteSV extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "sinhvienmanager";
    private static final String TABLE_NAME_SINHVIEN = "sinhvien";
    private static final String MSSV = "mssv";
    private static final String TEN_SV = "tensv";
    private static final String LOP = "lop";
    private static final int VERSION = 1;

    private static final String CREATE_TABLE_SINHVIEN = "CREATE TABLE " +TABLE_NAME_SINHVIEN+"("+
            MSSV + " integer primary key,"+
            TEN_SV+" nvarchar(100),"+
            LOP + " nvarchar(100))" ;






    private static final String TABLE_NAME_HOADON = "hoadon";
    private static final String MAHD = "mahd";
    private static final String MASV = "masv";
    private static final String NGAYLAP = "ngaplap";
    private static final String CREATE_TABLE_HOADON = "create table hoadon(mahd integer primary key,masv integer,ngaylap nvarchar(100))";
            ;


    private Context context;


    public SqliteSV(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_SINHVIEN);
        db.execSQL(CREATE_TABLE_HOADON);

        db.execSQL("insert into hoadon values(1,1,'ngay hom nay')");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }



    public long createHD(String masv) {
        long n = 0;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        Date date = new Date();
        values.put(NGAYLAP, String.valueOf(date));
        values.put(MASV, masv);

        n = db.insert(TABLE_NAME_HOADON, null, values);
        db.close();

        return n;

    }
    public long createSV(SinhVien sinhVien) {
        long n = 0;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues  values = new ContentValues();
        values.put(MSSV,sinhVien.getMssv() );
        values.put(TEN_SV,sinhVien.getTenSV() );
        values.put(LOP,sinhVien.getLop());

        n = db.insert(TABLE_NAME_SINHVIEN, null, values);
        db.close();

        return n;
    }



    public ArrayList<SinhVien> getAllSinhVien(){
        ArrayList<SinhVien> arrSV = new ArrayList<>();
        String query = "SELECT * FROM "+TABLE_NAME_SINHVIEN +";";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.moveToFirst()){
            do {
                SinhVien sv = new SinhVien();
                sv.setMssv(cursor.getInt(0));
                sv.setTenSV(cursor.getString(1));
                sv.setLop(cursor.getString(2));

                arrSV.add(sv);
            } while (cursor.moveToNext());
        }
        db.close();

        return arrSV;
    }


    public ArrayList<HoaDon> getAllHoaDonBySinhVien(String id) {
        ArrayList<HoaDon> arrHD = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME_HOADON +";";
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {

                int maHd = cursor.getInt(0);
                int maSV = cursor.getInt(2);

                String ngayLap = cursor.getString(1);

                HoaDon hd = new HoaDon(String.valueOf(maHd), String.valueOf(maSV), ngayLap);
                arrHD.add(hd);
            } while (cursor.moveToNext());
        }

        db.close();


        return arrHD;
    }


    public SinhVien getSinhVienById(String id){
        SinhVien sv = null;

        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME_SINHVIEN + " WHERE " + MSSV + " = '" + id + "'";
        Cursor cursor = db.rawQuery(query, null);

        if(!cursor.moveToFirst() || cursor.getCount()==0){
         return null;
        }else {
            cursor.moveToFirst();
            sv = new SinhVien(cursor.getInt(0), cursor.getString(1), cursor.getString(2));

        }
        db.close();


        return sv;
    }


    public long deleteSinhVienById(String id) {
        long n = 0;
        SQLiteDatabase db = this.getWritableDatabase();
        n = db.delete(TABLE_NAME_SINHVIEN, MSSV + "=?", new String[]{id});
        db.close();

        return n;
    }

    public long updateSinhVien(String id, String name, String lop) {
        long n = 0;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TEN_SV, name);
        values.put(LOP, lop);
        n = db.update(TABLE_NAME_SINHVIEN, values, MSSV + "=?", new String[]{String.valueOf(id)});
        db.close();
        return n;
    }





}
