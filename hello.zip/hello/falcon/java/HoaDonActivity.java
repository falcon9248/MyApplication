package com.example.falcon.cuoikyandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class HoaDonActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {


    private TextView tvTenSinhVien;
    private ListView lvHoaDon;
    private SinhVien sinhVien;
    private Button btnThemHD;
    private ArrayList<HoaDon> arrHD;
    SqliteSV sqliteSV;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hoa_don);


        init();




    }

    private void init() {



        tvTenSinhVien = findViewById(R.id.tvTenSinhVienHoaDon);
        lvHoaDon = findViewById(R.id.lvHoaDon);
        lvHoaDon.setOnItemClickListener(this);

        btnThemHD = findViewById(R.id.btnThemHD);
        btnThemHD.setOnClickListener(this);


        Intent intent = getIntent();
        Bundle bundle = intent.getBundleExtra(MainActivity.BUNDLE);

        sinhVien = (SinhVien) bundle.getSerializable("sinhvien");
        tvTenSinhVien.setText(sinhVien.getTenSV());


        sqliteSV = new SqliteSV(this);

        arrHD = sqliteSV.getAllHoaDonBySinhVien(String.valueOf(sinhVien.getMssv()));











    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnThemHD:
                themHD();
                break;
        }

    }

    private void themHD() {
        sqliteSV.createHD(tvTenSinhVien.getText().toString());


    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }
}
