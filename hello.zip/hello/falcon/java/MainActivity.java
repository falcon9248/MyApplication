package com.example.falcon.cuoikyandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {

    private EditText edtMSSV, edtTenSV, edtLop;
    private Button btnThem, btnXoa, btnSua,btnChiTiet;
    private ListView lvSV;
    private SqliteSV sqliteSV;
    private ArrayList<SinhVien> arrSV;
    private SinhVienAdapter adapter;




    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        createEvent();
    }



    private void init() {
        edtMSSV = findViewById(R.id.edtMSSV);
        edtTenSV = findViewById(R.id.edtHoVaTen);
        edtLop = findViewById(R.id.edtLop);

        btnThem = findViewById(R.id.btnThem);
        btnXoa = findViewById(R.id.btnXoa);
        btnSua = findViewById(R.id.btnSua);
        btnChiTiet = findViewById(R.id.btnChiTiet);

        btnSua.setEnabled(false);
        btnXoa.setEnabled(false);

        lvSV = findViewById(R.id.lvSV);
        sqliteSV = new SqliteSV(this);
        arrSV = sqliteSV.getAllSinhVien();
        adapter = new SinhVienAdapter(this, R.layout.custom_list_view, arrSV);
        lvSV.setAdapter(adapter);


    }


    private void createEvent() {
        this.btnThem.setOnClickListener(this);
        this.btnXoa.setOnClickListener(this);
        this.btnSua.setOnClickListener(this);
        this.btnChiTiet.setOnClickListener(this);

        this.lvSV.setOnItemClickListener(this);

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnThem:

                if (btnThem.getText().toString().equalsIgnoreCase("Them")) {
                    themSV();
                } else {
                    resetForm();
                }
                
                break;

            case R.id.btnSua:
                suaSV();
                break;


            case R.id.btnXoa:
                xoaSV();
                break;

            case R.id.btnChiTiet:
                hoaDonSV();
                break;
                
        }

    }

    public static  final String BUNDLE = "bundle";

    private void hoaDonSV() {
        SinhVien sv = new SinhVien(Integer.valueOf(edtMSSV.getText().toString()),
                edtTenSV.getText().toString(),
                edtLop.getText().toString()
                );

        Intent intent = new Intent(MainActivity.this,HoaDonActivity.class);
        Bundle bundle= new Bundle();
        bundle.putSerializable("sinhvien", sv);
        intent.putExtra(BUNDLE, bundle);
        startActivity(intent);


    }

    private void xoaSV() {
        if (sqliteSV.deleteSinhVienById(edtMSSV.getText().toString()) > 0) {
            Toast.makeText(this, "Xoa thanh cong", Toast.LENGTH_SHORT).show();

            resetForm();
            arrSV.clear();
            arrSV.addAll(sqliteSV.getAllSinhVien());
            adapter.notifyDataSetChanged();

        } else {
            Toast.makeText(this, "Xoa that bai", Toast.LENGTH_SHORT).show();
        }

    }

    private void suaSV() {
        if (edtTenSV.getText().toString().equals("")) {
            Toast.makeText(this, "nhap ten", Toast.LENGTH_SHORT).show();

        } else if (edtLop.getText().toString().equals("")) {
            Toast.makeText(this, "nhap Lop", Toast.LENGTH_SHORT).show();
        } else if (sqliteSV.updateSinhVien(edtMSSV.getText().toString(), edtTenSV.getText().toString(), edtLop.getText().toString()) > 0) {
            Toast.makeText(this, "cap nhat thanh cong", Toast.LENGTH_SHORT).show();
            resetForm();
            arrSV.clear();
            arrSV.addAll(sqliteSV.getAllSinhVien());
            adapter.notifyDataSetChanged();

        } else {
            Toast.makeText(this, "cap nhat that bai", Toast.LENGTH_SHORT).show();
        }

    }

    private void themSV() {
        if (edtMSSV.getText().toString().equals("")) {
            Toast.makeText(this, "nhap ma", Toast.LENGTH_SHORT).show();
        } else if (edtTenSV.getText().toString().equals("")) {
            Toast.makeText(this, "nhap ten", Toast.LENGTH_SHORT).show();

        } else if (edtLop.getText().toString().equals("")) {
            Toast.makeText(this,"nhap Lop", Toast.LENGTH_SHORT).show();
        } else if (sqliteSV.getSinhVienById(edtMSSV.getText().toString())!=null) {
            Toast.makeText(this, "trung ma sv", Toast.LENGTH_SHORT).show();

        } else if (sqliteSV.createSV(getInfo()) > 0) {

            Toast.makeText(this, "them thanh cong", Toast.LENGTH_SHORT).show();
            arrSV.clear();
            arrSV.addAll(sqliteSV.getAllSinhVien());
            adapter.notifyDataSetChanged();
            lvSV.setSelection(adapter.getCount() - 1);
            resetForm();

        } else {
            Toast.makeText(this, "them that bai", Toast.LENGTH_SHORT).show();
        }





    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        SinhVien sinhVien = arrSV.get(position);
        edtMSSV.setText(String.valueOf(sinhVien.getMssv()));
        edtTenSV.setText(sinhVien.getTenSV());
        edtLop.setText(sinhVien.getLop());
        btnSua.setEnabled(true);
        btnXoa.setEnabled(true);
        edtMSSV.setFocusable(false);
        edtMSSV.setEnabled(false);
        btnThem.setText("Hủy");

    }

    public void resetForm() {
        edtLop.setText("");
        edtTenSV.setText("");
        edtMSSV.setText("");

        btnThem.setText("Them");
        btnSua.setEnabled(false);
        btnXoa.setEnabled(false);

        edtMSSV.setEnabled(true);
        edtMSSV.setFocusable(true);
        edtMSSV.setFocusableInTouchMode(true);
        edtMSSV.requestFocus();
    }

    public SinhVien getInfo() {
        SinhVien sv = new SinhVien(Integer.valueOf(edtMSSV.getText().toString()),
                edtTenSV.getText().toString(),edtLop.getText().toString());


        return sv;
    }
}
